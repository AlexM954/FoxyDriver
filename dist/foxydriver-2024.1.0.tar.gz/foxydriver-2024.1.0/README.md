# FoxyDriver
FoxyDriver is a collection of tools written in Python for the remote operation of Foxy R1 and R2 fraction collectors, produced by Teledyne Technologies Incorporated. The Foxy line of instruments offer capabilities for remote control, but no utilities are provided by Teledyne out of the box. The tools in this repository aim to fill that gap.
